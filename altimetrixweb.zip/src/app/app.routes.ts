import { Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { Investment } from './investment/investment';

export const routes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    {path:"dashboard",component:Dashboard},
     
     {
    path: 'investment',
    loadChildren: () => import('./investment/investment.module').then(m => m.InvestmentModule)
  }
];
