import { Component } from '@angular/core';
import { ChartType, ChartConfiguration } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
@Component({
  selector: 'app-dashboard',
  imports: [BaseChartDirective],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard {
 pieChartType: ChartType = 'pie';
  pieChartLabels: string[] = ['Stocks', 'Bonds', 'Crypto', 'Real Estate'];
  //pieChartData: number[] = [40, 25, 20, 15];
  pieChartData: ChartConfiguration<'line'>['data']['datasets'] = [
    {
      data: [1000000, 1050000, 1100000, 1150000],
      label: 'Portfolio Value',
     backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f1c40f'],
      borderColor: 'green',
      fill: true
    },
    {
      data: [1000000, 1020000, 1040000, 1060000],
      label: 'Benchmark (Nifty 50)',
       backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f1c40f'],
     
      borderColor: '#95a5a6',
      fill: true
    }
  ];

  // Line Chart
  lineChartLabels: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  lineChartData: ChartConfiguration<'line'>['data']['datasets'] = [
    {
      data: [1000000, 1050000, 1100000, 1150000, 1200000, 1250000],
      label: 'Portfolio Value',
      borderColor: '#2980b9',
      fill: false
    },
    {
      data: [1000000, 1020000, 1040000, 1060000, 1080000, 1100000],
      label: 'Benchmark (Nifty 50)',
      borderColor: '#95a5a6',
      fill: false
    }
  ];
  lineChartType: ChartType = 'line';


}
