import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({ selector: '[appHighlightInput]' })
export class HighlightInputDirective {
  constructor(private el: ElementRef) {}

  @HostListener('focus') onFocus() {
    this.el.nativeElement.style.borderColor = '#3498db';
  }

  @HostListener('blur') onBlur() {
    this.el.nativeElement.style.borderColor = '#ccc';
  }
}
