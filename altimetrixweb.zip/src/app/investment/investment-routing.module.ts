import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import { Form } from './form/form';
import { Review } from './review/review';

const routes: Routes = [
  { path: '', redirectTo: 'form', pathMatch: 'full' },
  { path: 'form', component: Form },
  { path: 'review', component: Review }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvestmentRoutingModule {}
