import { createAction, props } from '@ngrx/store';
import { Investment } from './investment.model';

export const setInvestment = createAction('[Investment] Set', props<{ investment: Investment }>());
