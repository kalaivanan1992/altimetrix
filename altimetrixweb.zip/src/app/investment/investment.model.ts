export interface Investment {
  assetType: string;
  quantity: number;
  purchasePrice: number;
  date: string;
}