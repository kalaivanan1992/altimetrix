import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { investmentReducer } from './investment.reducer';

import { ReactiveFormsModule } from '@angular/forms';
import { InvestmentRoutingModule } from './investment-routing.module';
import { Form } from './form/form';
import { Review } from './review/review';

@NgModule({
  declarations: [ ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    InvestmentRoutingModule,
    
    Form,
    Review
  ], providers: [],
  bootstrap: [],
  
  exports: [],
})
export class InvestmentModule {}
