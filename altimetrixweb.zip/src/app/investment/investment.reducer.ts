import { createReducer, on } from '@ngrx/store';
import { setInvestment } from './investment.actions';
import { Investment } from './investment.model';

export const initialState: Investment = {
  assetType: '',
  quantity: 0,
  purchasePrice: 0,
  date: ''
};

export const investmentReducer = createReducer(
  initialState,
  on(setInvestment, (state, { investment }) => ({ ...investment }))
);
