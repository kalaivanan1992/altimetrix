import { createFeatureSelector } from '@ngrx/store';
import { Investment } from './investment.model';

export const selectInvestment = createFeatureSelector<Investment>('investment');
