import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-investment',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './investment.html',
  styleUrl: './investment.scss'
})
export class Investment {
   investmentForm!: FormGroup;
  investmentService: any;


  constructor(private fb: FormBuilder, private router: Router) {
    this.investmentForm = this.fb.group({
    assetType: ['', Validators.required],
    quantity: [0, [Validators.required, Validators.min(1)]],
    purchasePrice: [0, [Validators.required, Validators.min(1)]],
    date: ['', Validators.required]
  });
  }
 
  onSubmit() {
    if (this.investmentForm.valid) {
     this.investmentService.setInvestment(this.investmentForm.value);
      this.router.navigate(['/review']);
    }
  }
}
