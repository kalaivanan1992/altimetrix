import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Investment } from '../investment.model';
import { selectInvestment } from '../investment.selectors';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-review',
  standalone:true,
  imports:[CommonModule,ReactiveFormsModule],
  templateUrl: './review.html',
  styleUrls: ['./review.scss']
})
export class Review {
  investment$: Observable<Investment>;

  constructor(private store: Store, private router: Router) {
    this.investment$ = this.store.select(selectInvestment);
  }

  goBack() {
    this.router.navigate(['/investment/form']);
  }
}
